//
//  APIManager.swift
//  MoyaSample
//
//  Created By: IndiaNIC Infotech Ltd
//  Created on: 06/03/18 1:46 PM - (indianic)
//
//  Copyright © 2017 IndiaNIC Infotech Ltd. All rights reserved.
//
//

// https://github.com/Moya/Moya
// https://medium.com/@vsemenchenko/writing-network-layer-with-moya-for-swift-3aa039a6e693
// https://medium.com/@malcolmcollin/movie-app-swift-4-part-one-e6e03a993600

import Foundation
import UIKit
import Moya
import Alamofire
import SVProgressHUD
import SwiftyJSON


class APIManager: Alamofire.SessionManager {
    
    static let shared: APIManager = {
        
        let configuration = URLSessionConfiguration.default
        //        configuration.httpAdditionalHeaders = Alamofire.SessionManager.defaultHTTPHeaders
        configuration.timeoutIntervalForRequest = 120 // as seconds, you can set your request timeout
        configuration.timeoutIntervalForResource = 120 // as seconds, you can set your resource timeout
        //        configuration.requestCachePolicy = .useProtocolCachePolicy
        return APIManager(configuration: configuration)
        
    }()
    
}

class API {
    
    //    let pl = NetworkLoggerPlugin.init(verbose: true, cURL: nil, output: nil, requestDataFormatter: nil, responseDataFormatter: nil)
    
    //    static let provider = MoyaProvider<MyServerAPI>()
    static let provider = MoyaProvider<MyServerAPI>(manager: APIManager.shared, plugins: [NetworkLoggerPlugin(verbose: true)])
    
    //    static let provider = MoyaProvider<MyServerAPI>(plugins: [NetworkLoggerPlugin(verbose: true)])
    
    /// Use this method to call an API
    ///
    /// ````
    /// API.request(target: .getNeighborhoods(), success: { (response) in
    /// // parse your data
    /// print("parse your data", response)
    /// }, error: { (error) in
    /// // show error from server
    /// print("show error from server", error)
    /// }, failure: { (error) in
    /// // show Moya error
    /// print("show Moya error", error)
    /// })
    /// ````
    /// - Parameters:
    ///   - target: Your API Target.
    ///   - successCallback: Success block.
    ///   - errorCallback: Error block.
    ///   - failureCallback: failure block.
    static func request(target: MyServerAPI, isSilent:Bool = false, success successCallback: @escaping (JSON) -> Void, error errorCallback: @escaping (Swift.Error) -> Void, failure failureCallback: @escaping (MoyaError) -> Void) {
        
        // Progress is added to track. It is not working 100% so can be removed during final implementation.
        if !isSilent {
            SVProgressHUD.show()
        }
        provider.request(target, progress: { (response) in
            print(response.progress)
        }) { (result) in
            switch result {
            case .success(let response):
                // 1:
                
                SVProgressHUD.dismiss()
                print(response.statusCode)
                 if response.statusCode >= 200 && response.statusCode <= 300 {
                    if let json = try? JSON.init(data: response.data, options: JSONSerialization.ReadingOptions.allowFragments) {
                        successCallback(json)
                    }
                    else {
                        SVProgressHUD.dismiss()
                        let error = NSError(domain: "com.cosmic.networkLayer", code: 0, userInfo: [NSLocalizedDescriptionKey: "Parsing Error"])
                        errorCallback(error)
                    }
                } else {
                    // 2:
                    let error = NSError(domain:"com.indianic.networkLayer", code:0, userInfo:[NSLocalizedDescriptionKey: "Parsing Error"])
                    errorCallback(error)
                }
            case .failure(let error):
                // 3:
                SVProgressHUD.dismiss()
                failureCallback(error)
            }
        }
    }
}

// 1:
enum MyServerAPI {
    
    case userRegister()
    
}


// 2:
extension MyServerAPI: TargetType {
    
    /// The target's base `URL`.
    var baseURL: URL {
        guard let url = URL(string: "https://fakerestapi.azurewebsites.net/api/") else { fatalError("baseURL could not be configured") }
        return url
    }
    
    /// The path to be appended to `baseURL` to form the full `URL`.
    var path: String {
        switch self {
        case .userRegister:
            return "Books"
        }
    }
    
    /// The HTTP method used in the request.
    var method: Moya.Method {
        switch self {
        case .userRegister:
            return .get
        }
    }
    
    /// Provides stub data for use in testing.
    var sampleData: Data {
        return Data()
    }
    
    /// The type of HTTP task to be performed.
    var task: Task {
        switch self {
        case .userRegister():
            return .requestParameters(parameters: [:], encoding: URLEncoding.default)
        }
        
    }
    
    /// The headers to be used in the request.
    var headers: [String : String]? {
        switch self {
        case .userRegister:
            return ["Content-Type": "application/json"]
        }
    }
    
    /// The type of validation to perform on the request. Default is `.none`.
    var validationType: ValidationType {
        return .successCodes
    }
    
}
