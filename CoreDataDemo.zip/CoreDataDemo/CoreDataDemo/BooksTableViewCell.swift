//
//  BooksTableViewCell.swift
//  CoreDataDemo
//
//  Created by SOTSYS212 on 20/09/18.
//  Copyright © 2018 TEST. All rights reserved.
//

import UIKit

class BooksTableViewCell: UITableViewCell {

    @IBOutlet var lblBookDesc: UILabel!
    @IBOutlet var lblBookTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
