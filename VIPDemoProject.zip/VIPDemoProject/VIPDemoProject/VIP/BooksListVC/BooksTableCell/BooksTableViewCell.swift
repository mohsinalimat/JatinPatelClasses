//
//  BooksTableViewCell.swift
//  VIPDemoProject
//
//  Created by SOTSYS212 on 24/09/18.
//  Copyright © 2018 TEST. All rights reserved.
//

import UIKit

class BooksTableViewCell: UITableViewCell {

    @IBOutlet var lblBooksDes: UILabel!
    @IBOutlet var lblBooksTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
