//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by SOTSYS212 on 20/09/18.
//  Copyright © 2018 TEST. All rights reserved.
//
// (Pradicates tutorial)
//https://academy.realm.io/posts/nspredicate-cheatsheet/

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet var tblBook: UITableView!
    var dataToShow:[Book]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblBook.rowHeight = UITableViewAutomaticDimension
        tblBook.estimatedRowHeight = 500
        retriveData()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnRefresh(_ sender: UIBarButtonItem) {
        
        API.request(target: .userRegister(), success: { (response) in
            let managedContext =  appDelegate.persistentContainer.viewContext
            
            let bookEntity = NSEntityDescription.entity(forEntityName: "Book", in: managedContext)!
            
            
            for data in response.array! {
                let book = NSManagedObject(entity: bookEntity, insertInto: managedContext) as! Book
                book.id = data["ID"].int32!
                book.title = data["Title"].string
                book.excerpt = data["Excerpt"].string
                book.pagecount = data["PageCount"].int64!
                book.publishdate = Date()
                book.descriptions = data["Description"].string

            }
            
            do {
                try managedContext.save()
                if let documentsPathURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                    print("=====================\(documentsPathURL)===============================")
                    self.retriveData()
                }
            } catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
            self.tblBook.reloadData()
        }, error: { (error) in
            print(error.localizedDescription)
        }) { (moyaError) in
            print(moyaError.localizedDescription)
        }
        
    }
    
    func retriveData() {
        let request = NSFetchRequest<Book>.init(entityName: "Book")
//        request.returnsObjectsAsFaults = false
        request.sortDescriptors = [NSSortDescriptor.init(key: "id", ascending: true)]
        request.predicate = NSPredicate.init(format: "id < %d", 50)
        do {
            let result = try appDelegate.persistentContainer.viewContext.fetch(request)
            self.dataToShow =  result
            self.tblBook.reloadData()
            
        } catch {
            
            print("Failed")
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewController : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if let count = dataToShow?.count {
            return count
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let objCell  = tableView.dequeueReusableCell(withIdentifier: "BooksTableViewCell", for: indexPath) as! BooksTableViewCell
        if let data = self.dataToShow?[indexPath.row] {
            objCell.lblBookTitle.text = "\(data.title!)=======\(data.id)"
            objCell.lblBookDesc.text = data.descriptions
        }
        return objCell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    
}

